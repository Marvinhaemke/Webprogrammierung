<?php

$servername = "192.168.176.222"; 
$username = "server_S20028";
$password = "V9YnHyE1vxEZWluM";
$db = "server_S20028";

?>